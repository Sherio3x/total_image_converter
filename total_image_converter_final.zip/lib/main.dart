import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image/image.dart' as img;
import 'dart:io';
import 'dart:typed_data';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const TotalImageConverterApp());
}

class TotalImageConverterApp extends StatelessWidget {
  const TotalImageConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Total Image Converter',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const ImageConverterHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ImageConverterHome extends StatefulWidget {
  const ImageConverterHome({super.key});

  @override
  State<ImageConverterHome> createState() => _ImageConverterHomeState();
}

class _ImageConverterHomeState extends State<ImageConverterHome> {
  File? _selectedImage;
  String _selectedFormat = 'JPG';
  double _quality = 0.9;
  bool _isConverting = false;
  InterstitialAd? _interstitialAd;
  bool _isAdLoaded = false;

  final List<String> _formats = ['JPG', 'PNG', 'WebP'];
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadInterstitialAd();
  }

  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-5920925172530143/5617060626',
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          _interstitialAd = ad;
          _isAdLoaded = true;
        },
        onAdFailedToLoad: (LoadAdError error) {
          // Ad failed to load, continue without showing ad
        },
      ),
    );
  }

  void _showInterstitialAd() {
    if (_isAdLoaded && _interstitialAd != null) {
      _interstitialAd!.show();
      _interstitialAd = null;
      _isAdLoaded = false;
      // Load a new ad for next time
      _loadInterstitialAd();
    }
  }

  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      if (image != null) {
        setState(() {
          _selectedImage = File(image.path);
        });
      }
    } catch (e) {
      _showSnackBar('خطأ في اختيار الصورة: $e');
    }
  }

  Future<void> _convertImage() async {
    if (_selectedImage == null) {
      _showSnackBar('يرجى اختيار صورة أولاً');
      return;
    }

    setState(() {
      _isConverting = true;
    });

    try {
      // Read the original image
      final bytes = await _selectedImage!.readAsBytes();
      final originalImage = img.decodeImage(bytes);

      if (originalImage == null) {
        _showSnackBar('فشل في قراءة الصورة');
        return;
      }

      // Convert based on selected format
      Uint8List convertedBytes;
      String extension;

      switch (_selectedFormat) {
        case 'JPG':
          convertedBytes = Uint8List.fromList(
            img.encodeJpg(originalImage, quality: (_quality * 100).round())
          );
          extension = 'jpg';
          break;
        case 'PNG':
          convertedBytes = Uint8List.fromList(img.encodePng(originalImage));
          extension = 'png';
          break;
        case 'WebP':
          // WebP encoding is not available in the image package
          // We'll convert to PNG instead for now
          convertedBytes = Uint8List.fromList(img.encodePng(originalImage));
          extension = 'png';
          _showSnackBar('تم التحويل إلى PNG (WebP غير مدعوم حالياً)');
          break;
        default:
          _showSnackBar('صيغة غير مدعومة');
          return;
      }

      // Save the converted image
      final directory = await getExternalStorageDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'converted_image_$timestamp.$extension';
      final filePath = '${directory!.path}/$fileName';
      
      final convertedFile = File(filePath);
      await convertedFile.writeAsBytes(convertedBytes);

      _showSnackBar('تم تحويل الصورة بنجاح!\nحُفظت في: $filePath');
      
      // Show interstitial ad after successful conversion
      _showInterstitialAd();

    } catch (e) {
      _showSnackBar('خطأ في تحويل الصورة: $e');
    } finally {
      setState(() {
        _isConverting = false;
      });
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _interstitialAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Total Image Converter',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header section
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Icon(
                      Icons.image,
                      size: 64,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'محول الصور الشامل',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'حول صورك بين صيغ مختلفة بسهولة',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),

            // Image selection section
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'اختر صورة',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    if (_selectedImage != null) ...[
                      Container(
                        height: 200,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey[300]!),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(
                            _selectedImage!,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                    
                    ElevatedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.photo_library),
                      label: Text(_selectedImage == null 
                        ? 'اختر صورة من المعرض' 
                        : 'اختر صورة أخرى'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(fontSize: 16),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Conversion settings section
            Card(
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'إعدادات التحويل',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    
                    // Format selection
                    const Text(
                      'الصيغة المطلوبة:',
                      style: TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _selectedFormat,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                      ),
                      items: _formats.map((String format) {
                        return DropdownMenuItem<String>(
                          value: format,
                          child: Text(format),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          setState(() {
                            _selectedFormat = newValue;
                          });
                        }
                      },
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Quality slider (only for JPG and WebP)
                    if (_selectedFormat == 'JPG' || _selectedFormat == 'WebP') ...[
                      Text(
                        'الجودة: ${(_quality * 100).round()}%',
                        style: const TextStyle(fontSize: 16),
                      ),
                      Slider(
                        value: _quality,
                        min: 0.1,
                        max: 1.0,
                        divisions: 9,
                        onChanged: (double value) {
                          setState(() {
                            _quality = value;
                          });
                        },
                      ),
                    ],
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),

            // Convert button
            ElevatedButton.icon(
              onPressed: _isConverting ? null : _convertImage,
              icon: _isConverting 
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.transform),
              label: Text(_isConverting ? 'جاري التحويل...' : 'تحويل الصورة'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontSize: 18),
                backgroundColor: Theme.of(context).primaryColor,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

