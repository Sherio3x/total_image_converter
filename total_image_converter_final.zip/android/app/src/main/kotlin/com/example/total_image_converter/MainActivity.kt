package com.example.total_image_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
